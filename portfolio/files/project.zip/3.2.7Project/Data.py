# Designers: Brad Missakian, Chris Ly

import os.path
directory = os.path.dirname(os.path.abspath(__file__))  


month1=[]
player1=[]
month2=[]
player2=[]
month3=[]
player3=[]
month4=[]
player4=[]
month5=[]
player5=[]


for title in range(1,5):
    
    filename = os.path.join(directory, 'game'+str(title)+'.csv')
    datafile = open(filename,'r')
    
    for line in datafile:
        month, player = line.split(',')
        if title == 1:
            month1.append(month)
            player1.append(player)
        if title == 2:
            month2.append(month)
            player2.append(player)
        if title == 3:
            month3.append(month)
            player3.append(player)
        if title == 4:
            month4.append(month)
            player4.append(player)
        if title == 5:
            month5.append(month)
            player5.append(player)
    datafile.close()
    

import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 1)
ax.set_xlabel('From the relesed date of the game to January 2017')
ax.set_ylabel('Average Number of Players')
ax.plot(month1, player1, '#FF3333')
ax.plot(month2, player2, '#FFE800')
ax.plot(month3, player3, '#59FF00')
ax.plot(month4, player4, '#008FFF')
ax.plot(month5, player5, '#FF00A6')

ax.set_title('Blue: Call of Duty, Red: No Mans Sky, Yellow: Battleborn, Green: Division, ')
fig.show()

  
    
            